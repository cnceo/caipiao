<html xmlns="http://www.w3.org/1999/xhtml" style="font-size: 15.525px;"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width,height=device-height,initial-scale=1.0,user-scalable=no,maximum-scale=1.0">
<title>福彩168-官方网站</title>
<meta name="keywords" content="">
<meta name="format-detection" content="telephone=no">
<meta name="screen-orientation" content="portrait">
<meta name="x5-orientation" content="portrait">
<meta nam="description" content="">
<link rel="stylesheet" href="/css/nsc_m/res.css?v=1.16.12.11">
<link rel="stylesheet" href="/css/nsc_m/idangerous.swiper.css?v=1.16.12.11">
<link href="/js/nsc_m/need/layer.css?2.0" type="text/css" rel="styleSheet" id="layermcss">
<script type="text/javascript" src="/js/nsc/jquery-1.7.min.js?v=1.16.12.11"></script>
<script>var TIP=true;</script>
<script type="text/javascript" src="/skin/js/onload.js"></script>
<script type="text/javascript" src="/skin/js/function.js"></script>

 <script type="text/javascript" src="/js/nsc/common.js?v=1.16.12.11"></script>
<script type="text/javascript" src="/js/nsc_m/layer.js?v=1.16.12.11"></script>
<script type="text/javascript" src="/js/nsc_m/res.js?v=1.16.12.11"></script>
</head>
<script type='text/javascript'>
 function zxkf(){
	<?php if($this->settings['kefuStatus']){ ?>
	var newWin=window.open("<?=$this->settings['kefuGG']?>");
	<?php }else{?>
	xingcai("客服系统维护中");
	<?php }?>
	return false;
 }
</script> 
   <body style="overflow-x: visible;">
	<!-- 代码部分begin -->
	<div id="body" class="">
		<header class="header">
	<a href="/"><img class="logo" src="/images/nsc_m/index/logo.png?v=1.16.12.11"></a>
	<!-- <a class="m-return" href="javascript:checkbackspace();">返回</a> -->
	<span class="btn-slide-bar"></span>
	
	<div class="wercom ">
        <a class="uc_icon" href="/index.php/safe/Personal"></a><i class="ui_msgnum" style="display:none">0</i>
    </div>
</header>
<!--侧导航 -->
		<section class="slide-bar" style="display: none;">
			<ul class="tree">
				<li class="tree_list">
	                <h3 class="one_nav_list uc_icon_r"><a href="/index.php/safe/Personal">用户中心</a></h3>
	                <div class="m_nav_line"></div>
				</li>
				<li class="tree_box tree_list">
					<h3 class="one_nav_list  game_icon tree_box">彩票游戏<i class="lnstruction-top"></i></h3>
					<ul class="tree_one" style="display:block">
						<li class="lotter_list_game">
						<div class="m_nav_line"></div>
							<dl>
								<dt>高频彩</dt>
								<dd>
									<ul class="lot_list">
										<li><a href="/index.php/index/game/1/2/12">重庆时时彩<i>H</i></a> </li>
										<li><a href="/index.php/index/game/12/2/12">快乐时时彩</a> </li>
										<li><a href="/index.php/index/game/60/2/12">天津时时彩</a> </li>
										<li><!--<a href="/index.php/index/game/61/59/193">澳门时时彩<i>H</i>--></a> </li>
										<li><!--<a href="/index.php/index/game/62/59/193">台湾时时彩<i>H</i>--></a> </li>
										<li><a href="/index.php/index/game/5/59/193">河内1分彩<i>H</i></a> </li>
										<li><!--<a href="/index.php/index/game/26/59/193">河内2分彩<i>H</i>--></a> </li>
										<li><a href="/index.php/index/game/14/59/193">河内5分彩<i>H</i></a></li>
										<li><!--<a href="/index.php/index/game/76/59/193">巴西1.5分彩<i>H</i>--></a></li>
										<li><!--<a href="/index.php/index/game/75/59/193">巴西快乐彩<i>H</i>--></a></li>
										
										<!-- comingsoon();  如果需要禁用用这个函数即可--> 
									</ul>
								</dd>
							</dl>
							<dl>
							<dt>PK拾</dt>
								<dd>
									<ul class="lot_list">
										<li><a href="/index.php/index/game/20">北京PK拾<i class="m-yellow">N</i></a> </li>
										<li><!--<a href="/index.php/index/game/65">澳门PK拾<i class="m-yellow">N</i>--></a> </li>
										<li><!--<a href="/index.php/index/game/66">台湾PK拾<i class="m-yellow">N</i>--></a> </li>
									</ul>
								</dd>
							</dl>
							<dl>
							<dt><!--快3--></dt>
								<dd>
									<ul class="lot_list">
										<li><!--<a href="/index.php/index/game/79">江苏快三<i>H</i></a></li>
										<li><a href="/index.php/index/game/63">澳门快三</a></li>
										<li><a href="/index.php/index/game/64">台湾快三</a></li>-->
									</ul>
								</dd>
							</dl>
							<dl>
							<dt>11选5</dt>
								<dd>
									<ul class="lot_list">
										<li><a href="/index.php/index/game/6">广东11选5<i>H</i></a></li>
										<li><a href="/index.php/index/game/16">江西11选5</a></li>
										<li><a href="/index.php/index/game/7">山东11选5</a></li>
										<li><!--<a href="/index.php/index/game/15">上海11选5--></a></li>
										<li><!--<a href="/index.php/index/game/67">澳门11选5<i>H</i>--></a></li>
										<li><!--<a href="/index.php/index/game/68">台湾11选5--></a></li>
									</ul>
								</dd>
							</dl>
							<dl>
							<dt>快乐8</dt>
								<dd>
									<ul class="lot_list">
										<li><a href="/index.php/index/game/78">北京快乐8<i>H</i></a></li>
										<li><!--<a href="/index.php/index/game/74">韩国快乐8<i>H</i>--></a></li>
										<li><!--<a href="/index.php/index/game/73">澳门快乐8--></a></li>
									</ul>
								</dd>
							</dl>
							<dl>
								<dt><!--3D-排列3--></dt>
								<dd>
									<ul class="lot_list">
										<li><!--<a href="/index.php/index/game/9">福彩3D<i>H</i></a></li>
										<li><a href="/index.php/index/game/69">澳门3D</a></li>
										<li><a href="/index.php/index/game/70">台湾3D</a></li>
										<li><a href="/index.php/index/game/10">排列3</a></li>-->
									</ul>
								</dd>
							</dl>
						</li> 
					</ul>
					<div class="m_nav_line"></div>
				</li>
				
				<li class="tree_box tree_list">
					<h3 class="one_nav_list account_icon">账户管理<i class="lnstruction-top"></i></h3>
					<ul class="tree_one">
						<li class="lotter_list_game">
							<div class="m_nav_line"></div>
								<dl class="lnstruction">
									<dd>
										<ul class="lot_list">
											<li class="tree_list"> <a href="/index.php/record/search">投注记录</a></li>
											<li class="tree_list"> <a href="/index.php/report/coin">帐变记录</a></li>
											<li class="tree_list"> <a href="/index.php/report/count">盈亏报表</a></li>
											<li class="tree_list"><a href="/index.php/safe/info">绑定卡号 </a></li>
											<li class="tree_list"><a href="/index.php/safe/loginpasswd">登入密码</a></li>
											<li class="tree_list"><a href="/index.php/safe/passwd">提款密码</a></li>
										</ul>
									</dd>
								</dl>
						</li>
					</ul>
					<div class="m_nav_line"></div>
				</li>
				<?php if($this->user['type']){?>
				<li class="tree_box tree_list">
					<h3 class="one_nav_list team_icon">团队管理<i class="lnstruction-top"></i></h3>
					<ul class="tree_one">
						<li class="lotter_list_game">
								<div class="m_nav_line"></div>
							<dl class="lnstruction">
								<dd>
									<ul class="lot_list">
										<li class="tree_list"><a href="/index.php/team/gameRecord">团队记录</a></li>
										<li class="tree_list"><a href="/index.php/team/coin">团队帐变</a></li>
										<li class="tree_list"><a href="/index.php/team/report">团队盈亏</a></li>
										<li class="tree_list"><a href="/index.php/team/memberList">用户列表</a></li>
										<li class="tree_list"><a href="/index.php/team/addMember">注册管理</a></li>
										<li class="tree_list"><a href="/index.php/team/addlink">推广设定</a></li>
										<li class="tree_list"><a href="/index.php/team/linkList">链接管理</a></li>
										<li class="tree_list"><a href="/index.php/team/coinall">团队统计</a></li>
									</ul>
								</dd>
							</dl>
						</li>
					</ul>
					<div class="m_nav_line"></div>
				</li>
				<?}?>
				<li class="tree_box tree_list">
					<h3 class="one_nav_list account_icon">充值提现<i class="lnstruction-top"></i></h3>
					<ul class="tree_one">
						<li class="lotter_list_game">
							<div class="m_nav_line"></div>
								<dl class="lnstruction">
									<dd>
										<ul class="lot_list">
											<li class="tree_list"> <a href="/index.php/cash/recharge">充值</a></li>
											<li class="tree_list"> <a href="/index.php/cash/toCash">提现</a></li>
											<li class="tree_list"> <a href="/index.php/cash/rechargeLog">充值记录</a></li>
											<li class="tree_list"><a href="/index.php/cash/toCashLog">提现记录 </a></li>
										</ul>
									</dd>
								</dl>
						</li>
					</ul>
					<div class="m_nav_line"></div>
				</li>
				<li class="tree_box tree_list">
					<h3 class="one_nav_list activity_icon">优惠活动<i class="lnstruction-top"></i></h3>
					<ul class="tree_one">
						<li class="lotter_list_game">
							<div class="m_nav_line"></div>
								<dl class="lnstruction">
									<dd>
										<ul class="lot_list">
											<li class="tree_list"><a href="/index.php/score/lucky">幸运抽奖</a></li>
											<li class="tree_list"><a href="/index.php/cash/card">卡密充值</a></li>
											<li class="tree_list"><a href="/index.php/lottery/hemai">合买中心</a></li>
											<li class="tree_list"><a class="notice" href="/index.php/notice/info">系统公告</a></li>
										</ul>
									</dd>
								</dl>
						</li>
					</ul>
					<div class="m_nav_line"></div>
				</li>			
			</ul>
		</section>
		<div class="home_b" style="display: none;">
			<div class="m_nav_line"></div>
				<!-- <a href="">首页</a> -->
				<a class="one_nav_list conpt_icon" href="/?v=2">电脑版</a>
				<a class="one_nav_list retreat_icon" href="javascript:m_loginout()">安全退出</a>
		</div>
		<div class="shady" style="display: none;"></div>		<div class="m-prompt" style="overflow: hidden; display: none;">
			<img src="/images/nsc_m/index/question.png?v=1.16.12.11">
			<a href="javascript:;"></a>
		</div>
		<section class="wraper-page" style="overflow: visible;">
		<!-- 客服 -->
		<a class="customer" href="javascript:void(0)" onclick="zxkf();" target="_blank"></a>
		<!-- 客服 -->
		<!-- 轮播 -->
		<div class="swiper-container">
		  <div class="swiper-wrapper" style="width: 3312px; height: 102.016px; transform: translate3d(-2070px, 0px, 0px); transition-duration: 0.3s;">
		  <div class="swiper-slide swiper-slide-duplicate" style="width: 414px; height: 102.016px;">
                         	<a href="/?controller=promotions&amp;action=main&amp;tag=details#">
                                <img src="/images/uploads/1/yongjin.jpg">
                            </a>
                        </div>
		                                               <div class="swiper-slide" style="width: 414px; height: 102.016px;">
                         	<a href="/index.php/safe/Personal">
                                <img src="/images/uploads/1/2.jpg">
                            </a>
                        </div>
                                            <div class="swiper-slide" style="width: 414px; height: 102.016px;">
                         	<a href="/index.php/index/game/20">
                                <img src="/images/uploads/1/3.jpg">
                            </a>
                        </div>
                                            <div class="swiper-slide" style="width: 414px; height: 102.016px;">
                         	<a href="/?controller=promotions&amp;action=main&amp;tag=extremepoints#">
                                <img src="/images/uploads/1/7.jpg">
                            </a>
                        </div>
                                            <div class="swiper-slide" style="width: 414px; height: 102.016px;">
                         	<a href=" /?nav=pk10&amp;flaglot=pk10#">
                                <img src="/images/uploads/1/8.jpg">
                            </a>
                        </div>
						</div>
		<div class="pagination">
		<span class="swiper-pagination-switch"></span><span class="swiper-pagination-switch"></span>
		<span class="swiper-pagination-switch"></span><span class="swiper-pagination-switch"></span>
		<span class="swiper-pagination-switch swiper-visible-switch swiper-active-switch"></span>
		<span class="swiper-pagination-switch"></span>
		</div>
		</div>
		<!-- end轮播 -->
		<div class="v-moeny">
			<div class="you-money">
                <span class="t_money rounded" title="0.0000">
                    <div class="show-money" style="display: block;"><i>您的余额</i> <span id="refff" title="0.0000"><b>￥0.0000</b></span>
                    <a href="javascript:;" title="隐藏余额">
                     <i class="ic-unlook" title="隐藏余额"></i>
                </a></div>
                    <div class="hide-money" style="display: none;"><i>您的余额</i> <span><b>￥ ************</b></span>
                    	<a href="javascript:;" title="隐藏余额">
		                    <i class="ic-unlook" title="隐藏余额"></i>
		                </a>
                    </div>
                </span> 
                
			</div>
			<div class="chongzhi">
				<a class="rech" href="/index.php/cash/recharge">充值</a>
				<a class="withraw" href="/index.php/cash/toCash">提现</a>
			</div>
		</div>
		<!-- 选项卡 -->
		<div class="grandient-line"></div>
		<div class="moTab">
			<div class="Tab-nav">
				<div class="cur">热门彩票</div>
				<div>全部彩票</div>
			</div>
			<div class="Tab-content" style="display: block;">
			<ul class="lotteryList">
				<li>
					<div class="lotteryBox">
							<a class="cq_Ssc" href="/index.php/index/game/1/2/12">
								
							</a>
							<i class="smDot">热</i>
							<p class="lottName">重庆时时彩</p>
						</div>
				</li>
				<!--<li>
					<div class="lotteryBox">
							<a class="amssc" href="/index.php/index/game/61/59/193">
								
							</a>
							<i class="smDot">热</i>
							<p class="lottName">澳门时时彩</p>
						</div>
				</li>-->
				<!--<li>
					<div class="lotteryBox">
							<a class="twssc" href="/index.php/index/game/62/59/193">
								
							</a>
							<i class="smDot">热</i>
							<p class="lottName">台湾时时彩</p>
						</div>
				</li>-->
				<li>
					<div class="lotteryBox">
							<a class="tj_ssc" href="/index.php/index/game/60/2/12">
								
							</a>
							<i class="smDot">热</i>
							<p class="lottName">天津时时彩</p>
						</div>
				</li>
				<li>
					<div class="lotteryBox">
							<a class="xj_ssc" href="/index.php/index/game/12/2/12">
								
							</a>
							<i class="smDot">热</i>
							<p class="lottName">快乐时时彩</p>
						</div>
				</li>
				<li>
					<div class="lotteryBox">
							<a class="hn_1fc" href="/index.php/index/game/5/59/193">
								
							</a>
							<i class="smDot">热</i>
							<p class="lottName">河内1分彩</p>
						</div>
				</li>
				<!--<li>
					<div class="lotteryBox">
							<a class="hn_2fc" href="/index.php/index/game/26/59/193">
								
							</a>
							<i class="smDot">热</i>
							<p class="lottName">河内2分彩</p>
						</div>
				</li>-->
				<li>
					<div class="lotteryBox">
							<a class="hn_5fc" href="/index.php/index/game/14/59/193">
								
							</a>
							<i class="smDot ">热</i>
							<p class="lottName">河内5分彩</p>
						</div>
				</li>
				<!--<li>
					<div class="lotteryBox">
							<a class="bx_15fc" href="/index.php/index/game/76/59/193">
								
							</a>
							<i class="smDot ">热</i>
							<p class="lottName">巴西1.5分彩</p>
						</div>
				</li>-->
				<li>
					<div class="lotteryBox">
							<a class="bj_PK10" href="/index.php/index/game/20">
							
							</a>
							<i class="smDot">新</i>
							<p class="lottName">北京PK拾</p>
						</div>
				</li>
				<!--<li>
					<div class="lotteryBox">
							<a class="am_PK10" href="/index.php/index/game/65">
							
							</a>
							<i class="smDot">新</i>
							<p class="lottName">澳门PK拾</p>
						</div>
				</li>-->
				<!--<li>
					<div class="lotteryBox">
							<a class="tw_PK10" href="/index.php/index/game/66">
							
							</a>
							<i class="smDot">新</i>
							<p class="lottName">台湾PK拾</p>
						</div>
				</li>-->
				
				
				<!--li>
					<div class="lotteryBox">
							<a class="xg_6hc" href="/index.php/index/game/34">
							
							</a>
							<p class="lottName">香港六合彩</p>
						</div>
				</li-->
				
				<li>
					<div class="lotteryBox">
							<a class="bj_k" href="/index.php/index/game/78">
								
							</a>
							<p class="lottName">北京快乐8</p>
						</div>
				</li>
				<!--<li>
					<div class="lotteryBox">
							<a class="hg_k8" href="/index.php/index/game/74">
								
							</a>
							<p class="lottName">韩国快乐8</p>
						</div>
				</li>-->
				<!--<li>
					<div class="lotteryBox">
							<a class="am_k8" href="/index.php/index/game/73">
								
							</a>
							<p class="lottName">澳门快乐8</p>
						</div>
				</li>-->
			</ul>
				
			</div>
			<!-- 七彩游戏 -->
			<div class="Tab-content">
				<ul class="lotteryList">
				<li>
					<div class="lotteryBox">
							<a class="cq_Ssc" href="/index.php/index/game/1/2/12">
								
							</a>
							<i class="smDot">热</i>
							<p class="lottName">重庆时时彩</p>
						</div>
				</li>
				<!--<li>
					<div class="lotteryBox">
							<a class="amssc" href="/index.php/index/game/61/59/193">
								
							</a>
							<i class="smDot">热</i>
							<p class="lottName">澳门时时彩</p>
						</div>
				</li>-->
				<!--<li>
					<div class="lotteryBox">
							<a class="twssc" href="/index.php/index/game/62/59/193">
								
							</a>
							<i class="smDot">热</i>
							<p class="lottName">台湾时时彩</p>
						</div>
				</li>-->
				<li>
					<div class="lotteryBox">
							<a class="tj_ssc" href="/index.php/index/game/60/12/12">
								
							</a>
							<i class="smDot">热</i>
							<p class="lottName">天津时时彩</p>
						</div>
				</li>
				<li>
					<div class="lotteryBox">
							<a class="xj_ssc" href="/index.php/index/game/12/12/12">
								
							</a>
							<i class="smDot">热</i>
							<p class="lottName">快乐时时彩</p>
						</div>
				</li>
				<li>
					<div class="lotteryBox">
							<a class="hn_1fc" href="/index.php/index/game/5/59/193">
								
							</a>
							<i class="smDot">热</i>
							<p class="lottName">河内1分彩</p>
						</div>
				</li>
				<!--<li>
					<div class="lotteryBox">
							<a class="hn_2fc" href="/index.php/index/game/26/59/193">
								
							</a>
							<i class="smDot">热</i>
							<p class="lottName">河内2分彩</p>
						</div>
				</li>-->
				<li>
					<div class="lotteryBox">
							<a class="hn_5fc" href="/index.php/index/game/14/59/193">
								
							</a>
							<i class="smDot ">热</i>
							<p class="lottName">河内5分彩</p>
						</div>
				</li>
				<!--<li>
					<div class="lotteryBox">
							<a class="bx_15fc" href="/index.php/index/game/76/59/193">
								
							</a>
							<i class="smDot ">热</i>
							<p class="lottName">巴西1.5分彩</p>
						</div>
				</li>-->
				<!--<li>
					<div class="lotteryBox">
							<a class="bx_ssc" href="/index.php/index/game/76/59/193">
								
							</a>
							<i class="smDot ">热</i>
							<p class="lottName">巴西快乐彩</p>
						</div>
				</li>-->
				<li>
					<div class="lotteryBox">
							<a class="bj_PK10" href="/index.php/index/game/20">
							
							</a>
							<i class="smDot">新</i>
							<p class="lottName">北京PK拾</p>
						</div>
				</li>
				<!--<li>
					<div class="lotteryBox">
							<a class="am_PK10" href="/index.php/index/game/65">
							
							</a>
							<i class="smDot">新</i>
							<p class="lottName">澳门PK拾</p>
						</div>
				</li>-->
				<!--<li>
					<div class="lotteryBox">
							<a class="tw_PK10" href="/index.php/index/game/66">
							
							</a>
							<i class="smDot">新</i>
							<p class="lottName">台湾PK拾</p>
						</div>
				</li>-->
				
				
				<!--li>
					<div class="lotteryBox">
							<a class="xg_6hc" href="/index.php/index/game/34">
							
							</a>
							<p class="lottName">香港六合彩</p>
						</div>
				</li-->
				
				<li>
					<div class="lotteryBox">
							<a class="bj_k" href="/index.php/index/game/78">
								
							</a>
							<p class="lottName">北京快乐8</p>
						</div>
				</li>
				<!--<li>
					<div class="lotteryBox">
							<a class="hg_k8" href="/index.php/index/game/74">
								
							</a>
							<p class="lottName">韩国快乐8</p>
						</div>
				</li>-->
				<!--<li>
					<div class="lotteryBox">
							<a class="am_k8" href="/index.php/index/game/73">
								
							</a>
							<p class="lottName">澳门快乐8</p>
						</div>
				</li>-->
					<!--<li>
					<div class="lotteryBox">
							<a class="sh_11x5" href="/index.php/index/game/15">
								
							</a>
							<i class="smDot">热</i>
							<p class="lottName">上海11选5</p>
						</div>
				</li>-->
				<!--<li>
					<div class="lotteryBox">
							<a class="am_11x5" href="/index.php/index/game/67">
								
							</a>
							<i class="smDot">热</i>
							<p class="lottName">澳门11选5</p>
						</div>
				</li>-->
				<!--<li>
					<div class="lotteryBox">
							<a class="tw_11x5" href="/index.php/index/game/68">
								
							</a>
							<i class="smDot">热</i>
							<p class="lottName">台湾11选5</p>
						</div>
				</li>-->
				<li>
					<div class="lotteryBox">
							<a class="gd_11x5" href="/index.php/index/game/6">
								
							</a>
							<i class="smDot">热</i>
							<p class="lottName">广东11选5</p>
						</div>
				</li>
				<li>
					<div class="lotteryBox">
							<a class="jx_11x5" href="/index.php/index/game/16">
								
							</a>
							<p class="lottName">江西11选5</p>
						</div>
				</li>
				<li>
					<div class="lotteryBox">
							<a class="sd_11x5" href="/index.php/index/game/7">
							
							</a>
							<p class="lottName">山东11选5</p>
						</div>
				</li>
				<!--<li>
					<div class="lotteryBox">
							<a class="fc_3d" href="/index.php/index/game/9">
							
							</a>
							<i class="smDot ">热</i>
							<p class="lottName">3D福彩</p>
						</div>
				</li>-->
				<!--<li>
					<div class="lotteryBox">
							<a class="am_3d" href="/index.php/index/game/69">
							
							</a>
							<i class="smDot ">热</i>
							<p class="lottName">澳门3D</p>
						</div>
				</li>-->
				<!--<li>
					<div class="lotteryBox">
							<a class="tw_3d" href="/index.php/index/game/70">
							
							</a>
							<i class="smDot ">热</i>
							<p class="lottName">台湾3D</p>
						</div>
				</li>-->
				<!--<li>
					<div class="lotteryBox">
							<a class="js_k3" href="/index.php/index/game/79">
								
							</a>
							<i class="smDot ">热</i>
							<p class="lottName">江苏快三</p>
						</div>
				</li>-->
				<!--<li>
					<div class="lotteryBox">
							<a class="am_k3" href="/index.php/index/game/63">
								
							</a>
							<i class="smDot ">热</i>
							<p class="lottName">澳门快三</p>
						</div>
				</li>-->
				<!--<li>
					<div class="lotteryBox">
							<a class="tw_k3" href="/index.php/index/game/64">
								
							</a>
							<i class="smDot ">热</i>
							<p class="lottName">台湾快三</p>
						</div>
				</li>-->
				<!--<li>
					<div class="lotteryBox">
							<a class="pl_3" href="/index.php/index/game/10">
							
							</a>
							<p class="lottName">排列3</p>
						</div>
				</li>-->
				</ul>
			</div>
		
		<!-- end选项卡 -->
		</div>
		    <div class="res_fx_bottm chongzhi_f_botm">
      <b class="cz_close"></b>
      温馨提示：虚拟卡密充值，在右侧导航优惠活动里面。需要卡密请联系平台管理员
    </div>
		</section>
	</div>
	<!-- 代码部分end -->

   	<script type="text/javascript" src="/js/nsc_m/idangerous.swiper.min.js?v=1.16.12.11"></script>
    <script type="text/javascript" src="/js/nsc/main.js?v=1.16.12.11"></script>
    <script type="text/javascript">
	    $(".cz_close").click(function(){
        $(".chongzhi_f_botm").hide();
    })
    	var mySwiper = new Swiper('.swiper-container',{
		    loop: true,
			autoplay: 3000,
			pagination:'.pagination',
			paginationClickable:true
  		});

  		function m_loginout(){
            layer.open({
                content:'您需要退出账号吗？',
                btn:['退出','取消'],
                yes:function(){
                    window.location.href='/index.php/user/logout'
                }
            })
        }
         refreshMoney();
         //选项卡
        $(".Tab-content").eq(0).show();
        $(".Tab-nav div").click(function(){
	        $(".Tab-content").hide();
	        $(".Tab-nav div").removeClass("cur");
	        $(this).addClass("cur");
	        $(".Tab-content").eq($(this).index()).show()
        });
        //隐藏金额
	  	(function(){
		    var $ref = $("#refff"),$refresh = $(".ic-refresh"),$showMoney = $(".show-money"),$hideMoney = $(".hide-money");
		    	$hide = $(".ic-unlook");
		    var cvis = getCookie("hide");
		    if(cvis === "true"){
		    	$showMoney.hide();
		    	$hideMoney.show();
		      	$refresh.css("display","none");
		      	$hide.addClass("hide");
		      	$hide.attr("title","显示余额");
		    }else{
		    	$refresh.css("display","inline-block");
		    	$hide.attr("title","隐藏余额");
		    	$showMoney.show();
		    	$hideMoney.hide();
		    }
		    $hide.on("click",function(){ 
		      	var vis = $showMoney.css("display");
		      	if(vis == "none"){
			        setCookie("hide","false");
			        $showMoney.show();
		    		$hideMoney.hide();
			        $refresh.css("display","inline-block");
			        $hide.removeClass("hide");
			        $hide.attr("title","隐藏余额");        
			        refreshMoney();
		      	}else{
			        setCookie("hide","true");
			        $showMoney.hide();
		    		$hideMoney.show();  
			        $refresh.css("display","none");
			        $hide.addClass("hide");
			        $hide.attr("title","显示余额");
		      	}
		    });
		    var pormpt = getCookie("sex")
		    if(pormpt == "true"){
		    	$(".m-prompt").hide(0);
			}else{
			   $(".m-prompt").show(0);
			}
		    $(".m-prompt a").on("click",function(){
		    	setCookie("sex","true");
		    	$(".m-prompt").hide();
		    })

	  	})();
	  
    </script>
</body></html>