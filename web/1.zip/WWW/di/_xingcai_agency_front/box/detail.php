
	<div style="height:170px; padding:0 0 0 420px; background:url(/images/xsrw_06.jpg) no-repeat right bottom;">
				<div style="width:271px; height:60px; padding:10px 40px 0 10px; font:12px/24px '宋体'; color:#666; background:url(/images/xsrw_07.gif) no-repeat;">
					<?=$args[0]['content']?>
				</div>
			</div>
			 </div>