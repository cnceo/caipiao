﻿<?php
class xingcai extends WebBase{
	public $title='杏彩自主研发系统彩';
	/**
	 * 获取信息页面
	 */
	public final function xcffc(){
		$this->display('xingcai/ffc.php');
	}
	public final function xc2fc(){
		$this->display('xingcai/2fc.php');
	}
	public final function xc5fc(){
		$this->display('xingcai/5fc.php');
	}
	public final function xclhc(){
		$this->display('xingcai/lhc.php');
	}
	
	public final function xcampk10(){
		$this->display('xingcai/ampk10.php');
	}	
	public final function xctwpk10(){
		$this->display('xingcai/twpk10.php');
	}
	public final function xcamklsf(){
		$this->display('xingcai/amklsf.php');
	}
	public final function xctwklsf(){
		$this->display('xingcai/twklsf.php');
	}
	public final function xcamkl8(){
		$this->display('xingcai/amkl8.php');
	}	
	public final function xchgkl8(){
		$this->display('xingcai/hgkl8.php');
	}
	public final function xcamk3(){
		$this->display('xingcai/amk3.php');
	}
	public final function xctwk3(){
		$this->display('xingcai/twk3.php');
	}
	public final function xcam11(){
		$this->display('xingcai/am11.php');
	}	
	public final function xctw11(){
		$this->display('xingcai/tw11.php');
	}		
	public final function xcam3d(){
		$this->display('xingcai/am3d.php');
	}	
	public final function xctw3d(){
		$this->display('xingcai/tw3d.php');
	}			
	
	public final function xcamssc(){
		$this->display('xingcai/amssc.php');
	}	
	public final function xctwssc(){
		$this->display('xingcai/twssc.php');
	}		
	public final function xcbxklc(){
		$this->display('xingcai/bxklc.php');
	}	
	public final function xcbx15(){
		$this->display('xingcai/bx15.php');
	}		
	
	
	
	
	
	
}
