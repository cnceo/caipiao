﻿<?php
class activity extends WebLoginBase{
	public $title='\x51\x51\x34\x31\x30\x37\x34\x39\x39\x38\x35';   

	public final function newyear(){
		$this->display('activity/info.php');
	}
}
