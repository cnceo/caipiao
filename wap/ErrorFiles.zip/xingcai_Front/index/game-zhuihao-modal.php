
<div src="/index.php/index/zhuiHaoQs/" rel="2.000" style="display: block; width: auto; min-height: 0px; height: 230px;">
<div  style="position: relative;
    font-weight: bold;
    border-top: 1px solid #e6e6e6;
    /* border-bottom: 1px solid #e6e6e6; */
    border-right: 1px solid #e6e6e6;
    border-left: 1px solid #e6e6e6;
    line-height: 25px;
    text-align: center;
    font-size: 13px;
    overflow: hidden;
    background: #fff;
    width: 100%;
    margin: 0 auto;
    padding: 1rem 0 0.8rem 1rem;
    border-bottom: 1px solid #e6e6e6;">
<select name="qh" style="    width: 8.2rem;
    height: 1.8rem;
    line-height: 1.8rem;
    text-align: center;
    border: 1px solid #dddddd;
    border-radius: 0.2rem;
    background: #f5f5f5;
    margin-right: 0.3rem;">
<option value="10">最近10期</option>
<option value="20">最近20期</option>
<option value="30">最近30期</option>
<option value="40">最近40期</option>
<option value="50">最近50期</option>
<option value="0">今天全部</option>
</select>
<label><input style="margin-left: 30px;" type="checkbox" checked name="zhuiHaoMode" value="1"/>中奖后停止追号</label>
</div>
<div class="yxlist" >
<table border="0" cellpadding="0" cellspacing="0" style="width:100%;">
	<thead class="tr-top">
		<tr>
			<td><input type="checkbox"/></td>
			<td>期号</td>
			<td>倍数</td>
			<td>金额</td>
			<td>开奖时间</td>
		</tr>
	</thead>
	<tbody  class="tr-cont">
	</tbody>
</table>
</div>