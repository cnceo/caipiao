<input type="hidden" name="playedGroup" value="<?=$this->groupId?>" />
<input type="hidden" name="playedId" value="<?=$this->played?>" />
<input type="hidden" name="type" value="<?=$this->type?>" />
<div class="dGameStatus hklhc lotteryView_lhc" action="tzlhcSelect" length="1">
  <div class="Contentbox" id="Contentbox_0">
   <!-- <p class="sign-wrapper">
    	<span class="code_sign">号码</span>
    	<span class="pl">赔率</span>
    	<span><input placeholder="金额"/></span>
    </p>    -->
    <div class="lhcBox" >
		<dl>
			<dt><span>号码</span><span>赔率</span><span>金额</span></dt>
			<dd>
			<span id="RteSP01" class="red">01</span><span class="num" data-id="RteSP01"><?=$this->getLHCRte('RteSP01',$this->played)?></span>
			<span class="input"><input id="RteSP01" name="SP" maxlength="5" acno="01" type="text"></span>
			</dd>
			<dd>
			<span class="red">02</span><span class="num" data-id="RteSP02"><?=$this->getLHCRte('RteSP02',$this->played)?></span>
			<span class="input"><input id="RteSP02" name="SP" maxlength="5" acno="02" type="text"></span>
			</dd><dd>
			<span class="blue">03</span><span class="num" data-id="RteSP03"><?=$this->getLHCRte('RteSP03',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP03" name="SP" acno="03" type="text"></span>
			</dd><dd>
			<span class="blue">04</span><span class="num" data-id="RteSP04"><?=$this->getLHCRte('RteSP04',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP04" name="SP" acno="04" type="text"></span>
			</dd><dd>
			<span class="green">05</span><span class="num" data-id="RteSP05"><?=$this->getLHCRte('RteSP05',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP05" name="SP" acno="05" type="text"></span>
			</dd><dd>
			<span class="green">06</span><span class="num" data-id="RteSP06"><?=$this->getLHCRte('RteSP06',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP06" name="SP" acno="06" type="text"></span>
			</dd><dd>
			<span class="red">07</span><span class="num" data-id="RteSP07"><?=$this->getLHCRte('RteSP07',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP07" name="SP"  acno="07" type="text"></span>
			</dd><dd>
			<span class="red">08</span><span class="num" data-id="RteSP08"><?=$this->getLHCRte('RteSP08',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP08" name="SP" acno="08" type="text"></span>
			</dd><dd>
			<span class="blue">09</span><span class="num" data-id="RteSP09"><?=$this->getLHCRte('RteSP09',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP09" name="SP" acno="09" type="text"></span>
			</dd><dd>
			<span class="blue">10</span><span class="num" data-id="RteSP10"><?=$this->getLHCRte('RteSP10',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP10" name="SP" acno="10" type="text"></span>
			</dd>
		</dl>
		<dl>
			<dt>
				<span>号码</span><span>赔率</span><span>金额</span>
			</dt>
			<dd>
			<span class="green">11</span><span class="num" data-id="RteSP11"><?=$this->getLHCRte('RteSP11',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP11" name="SP"  acno="11" type="text"></span>
			</dd><dd>
			<span class="red">12</span><span class="num" data-id="RteSP12"><?=$this->getLHCRte('RteSP12',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP12" name="SP" acno="12" type="text"></span>
			</dd><dd>
			<span class="red">13</span><span class="num" data-id="RteSP13"><?=$this->getLHCRte('RteSP13',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP13" name="SP" acno="13" type="text"></span>
			</dd><dd>
			<span class="blue">14</span><span class="num" data-id="RteSP14"><?=$this->getLHCRte('RteSP14',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP14" name="SP" acno="14" type="text"></span>
			</dd><dd>
			<span class="blue">15</span><span class="num" data-id="RteSP15"><?=$this->getLHCRte('RteSP15',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP15" name="SP" acno="14" type="text"></span>
			</dd><dd>
			<span class="green">16</span><span class="num" data-id="RteSP16"><?=$this->getLHCRte('RteSP16',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP16" name="SP" acno="16" type="text"></span>
			</dd><dd>
			<span class="green">17</span><span class="num" data-id="RteSP17"><?=$this->getLHCRte('RteSP17',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP17" name="SP" acno="17" type="text"></span>
			</dd><dd>
			<span class="red">18</span><span class="num" data-id="RteSP18"><?=$this->getLHCRte('RteSP18',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP18" name="SP" acno="18" type="text"></span>
			</dd><dd>
			<span class="red">19</span><span class="num" data-id="RteSP19"><?=$this->getLHCRte('RteSP19',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP19" name="SP" acno="19" type="text"></span>
			</dd><dd>
			<span class="blue">20</span><span class="num" data-id="RteSP20"><?=$this->getLHCRte('RteSP20',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP20" name="SP" acno="20" type="text"></span>
			</dd>
		</dl>
		<dl>
			<dt>
				<span>号码</span><span>赔率</span><span>金额</span>
			</dt>
			<dd>
			<span class="green">21</span><span class="num" data-id="RteSP21"><?=$this->getLHCRte('RteSP21',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP21" name="SP"  acno="21" type="text"></span>
			</dd><dd>
			<span class="green">22</span><span class="num" data-id="RteSP22"><?=$this->getLHCRte('RteSP22',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP22" name="SP"  acno="22" type="text"></span>
			</dd><dd>
			<span class="red">23</span><span class="num" data-id="RteSP23"><?=$this->getLHCRte('RteSP23',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP23" name="SP"  acno="23" type="text"></span>
			</dd><dd>
			<span class="red">24</span><span class="num" data-id="RteSP24"><?=$this->getLHCRte('RteSP24',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP24" name="SP"  acno="24" type="text"></span>
			</dd><dd>
			<span class="blue">25</span><span class="num" data-id="RteSP25"><?=$this->getLHCRte('RteSP25',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP25" name="SP"  acno="25" type="text"></span>
			</dd><dd>
			<span class="blue">26</span><span class="num" data-id="RteSP26"><?=$this->getLHCRte('RteSP26',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP26" name="SP"  acno="26" type="text"></span>
			</dd><dd>
			<span class="green">27</span><span class="num" data-id="RteSP27"><?=$this->getLHCRte('RteSP27',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP27" name="SP"  acno="27" type="text"></span>
			</dd><dd>
			<span class="green">28</span><span class="num" data-id="RteSP28"><?=$this->getLHCRte('RteSP28',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP28" name="SP"  acno="28" type="text"></span>
			</dd><dd>
			<span class="red">29</span><span class="num" data-id="RteSP29"><?=$this->getLHCRte('RteSP29',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP29" name="SP"  acno="29" type="text"></span>
			</dd><dd>
			<span class="red">30</span><span class="num" data-id="RteSP30"><?=$this->getLHCRte('RteSP30',$this->played)?></span>
			<span class="input"><input maxlength="5" id="RteSP30" name="SP"  acno="30" type="text"></span>
			</dd>
		</dl>
		<dl>
			<dt>
		<span>号码</span><span>赔率</span><span>金额</span>
			</dt>
		<dd>
		<span class="blue">31</span><span class="num" data-id="RteSP31"><?=$this->getLHCRte('RteSP31',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteSP31" name="SP" acno="31" type="text"></span>
		</dd><dd>
		<span class="green">32</span><span class="num" data-id="RteSP32"><?=$this->getLHCRte('RteSP32',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteSP32" name="SP" acno="32" type="text"></span>
		</dd><dd>
		<span class="green">33</span><span class="num" data-id="RteSP33"><?=$this->getLHCRte('RteSP33',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteSP33" name="SP" acno="33" type="text"></span>
		</dd><dd>
		<span class="red">34</span><span class="num" data-id="RteSP34"><?=$this->getLHCRte('RteSP34',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteSP34" name="SP" acno="34" type="text"></span>
		</dd><dd>
		<span class="red">35</span><span class="num" data-id="RteSP35"><?=$this->getLHCRte('RteSP35',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteSP35" name="SP" acno="35" type="text"></span>
		</dd><dd>
		<span class="blue">36</span><span class="num" data-id="RteSP36"><?=$this->getLHCRte('RteSP36',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteSP36" name="SP" acno="36" type="text"></span>
		</dd><dd>
		<span class="blue">37</span><span class="num" data-id="RteSP37"><?=$this->getLHCRte('RteSP37',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteSP37" name="SP" acno="37" type="text"></span>
		</dd><dd>
		<span class="green">38</span><span class="num" data-id="RteSP38"><?=$this->getLHCRte('RteSP38',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteSP38" name="SP" acno="38" type="text"></span>
		</dd><dd>
		<span class="green">39</span><span class="num" data-id="RteSP39"><?=$this->getLHCRte('RteSP39',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteSP39" name="SP" acno="39" type="text"></span>
		</dd><dd>
		<span class="red">40</span><span class="num" data-id="RteSP40"><?=$this->getLHCRte('RteSP40',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteSP40" name="SP" acno="40" type="text"></span>
		</dd></dl>
		<dl>
			<dt>
		<span>号码</span><span>赔率</span><span>金额</span>
			</dt>
		<dd>
		<span class="blue">41</span><span class="num" data-id="RteSP41"><?=$this->getLHCRte('RteSP41',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteSP41" name="SP" acno="41" type="text"></span>
		</dd><dd>
		<span class="blue">42</span><span class="num" data-id="RteSP42"><?=$this->getLHCRte('RteSP42',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteSP42" name="SP" acno="42" type="text"></span>
		</dd><dd>
		<span class="green">43</span><span class="num" data-id="RteSP43"><?=$this->getLHCRte('RteSP43',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteSP43" name="SP" acno="43" type="text"></span>
		</dd><dd>
		<span class="green">44</span><span class="num" data-id="RteSP44"><?=$this->getLHCRte('RteSP44',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteSP44" name="SP" acno="44" type="text"></span>
		</dd><dd>
		<span class="red">45</span><span class="num" data-id="RteSP45"><?=$this->getLHCRte('RteSP45',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteSP45" name="SP" acno="45" type="text"></span>
		</dd><dd>
		<span class="red">46</span><span class="num" data-id="RteSP46"><?=$this->getLHCRte('RteSP46',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteSP46" name="SP" acno="46" type="text"></span>
		</dd><dd>
		<span class="blue">47</span><span class="num" data-id="RteSP47"><?=$this->getLHCRte('RteSP47',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteSP47" name="SP" acno="47" type="text"></span>
		</dd><dd>
		<span class="blue">48</span><span class="num" data-id="RteSP48"><?=$this->getLHCRte('RteSP48',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteSP48" name="SP" acno="48" type="text"></span>
		</dd>
		<dd>
		<span class="green">49</span><span class="num" data-id="RteSP49"><?=$this->getLHCRte('RteSP49',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteSP49" name="SP" acno="49" type="text"></span>
		</dd><dd>
		</dd>
		</dl>
		
		
		<div class="dGameStatus hklhc lotteryView_lhc2" action="tzlhcSelect" length="1">
                <div class="Contentbox" id="Contentbox_0">
        <div class="lhcBox2" >
		<dl>
			<dt>
		<span>号码</span><span style="width:76px;">赔率</span><span style="width:28px;">金额</span>
			</dt>
		<dd>
		<span id="RteSPBSOED1" class="sGameStatusItem">特大</span><span class="num" style="margin-left:12px;" data-id="RteSPBSOED"><?=$this->getLHCRte('RteSPBSOED',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteSPBSOED" name="SPBSOE" acno="特大" type="text"></span>
		</dd>
		<dd>
		<span id="RteSPBSOES1" class="sGameStatusItem">特小</span><span class="num" style="margin-left:12px;" data-id="RteSPBSOES"><?=$this->getLHCRte('RteSPBSOES',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteSPBSOES" name="SPBSOE" acno="特小" type="text"></span>
		</dd>
		<dd>
		<span id="RteSPH2DO1" class="sGameStatusItem">大单</span><span class="num" style="margin-left:12px;" data-id="RteSPH2DO"><?=$this->getLHCRte('RteSPH2DO',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteSPH2DO" name="SPH2" acno="大单" type="text"></span>
		</dd>
		<dd>
		<span id="RteSPBSOEO1" class="sGameStatusItem">特单</span><span class="num" style="margin-left:12px;" data-id="RteSPBSOEO"><?=$this->getLHCRte('RteSPBSOEO',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteSPBSOEO" name="SPBSOE" acno="特单" type="text"></span>
		</dd>
		<dd>
		<span id="RteSPBSOEE1" class="sGameStatusItem">特双</span><span class="num" style="margin-left:12px;" data-id="RteSPBSOEE"><?=$this->getLHCRte('RteSPBSOEE',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteSPBSOEE" name="SPBSOE" acno="特双" type="text"></span>
		</dd>
		<dd>
		<span id="RteSPH2DE1" class="sGameStatusItem">大双</span><span class="num" style="margin-left:12px;" data-id="RteSPH2DE"><?=$this->getLHCRte('RteSPH2DE',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteSPH2DE" name="SPH2" acno="大单" type="text"></span>
		</dd>
		<dd>
		<span id="RteSPTBSOED1" class="sGameStatusItem">合大</span><span class="num" style="margin-left:12px;" data-id="RteSPTBSOED"><?=$this->getLHCRte('RteSPTBSOED',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteSPTBSOED" name="SPTBSOE" acno="合大" type="text"></span>
		</dd>
		<dd>
		<span id="RteSPTBSOES1" class="sGameStatusItem">合小</span><span class="num" style="margin-left:12px;" data-id="RteSPTBSOES"><?=$this->getLHCRte('RteSPTBSOES',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteSPTBSOES" name="SPTBSOE" acno="合小" type="text"></span>
		</dd>
		<dd>
		<span id="RteSPH2SO1" class="sGameStatusItem">小单</span><span class="num" style="margin-left:12px;" data-id="RteSPH2SO"><?=$this->getLHCRte('RteSPH2SO',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteSPH2SO" name="SPH2" acno="小单" type="text"></span>
		</dd>
		<dd>
		<span id="RteSPTBSOEO1" class="sGameStatusItem">合单</span><span class="num" style="margin-left:12px;" data-id="RteSPTBSOEO"><?=$this->getLHCRte('RteSPTBSOEO',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteSPTBSOEO" name="SPTBSOE" acno="合单" type="text"></span>
		</dd>
		<dd>
		<span id="RteSPTBSOEE1" class="sGameStatusItem">合双</span><span class="num" style="margin-left:12px;" data-id="RteSPTBSOEE"><?=$this->getLHCRte('RteSPTBSOEE',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteSPTBSOEE" name="SPTBSOE" acno="合双" type="text"></span>
		</dd>
		<dd>
		<span id="RteSPH2SE1" class="sGameStatusItem">小双</span><span class="num" style="margin-left:12px;" data-id="RteSPH2SE"><?=$this->getLHCRte('RteSPH2SE',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteSPH2SE" name="SPH2" acno="小双" type="text"></span>
		</dd>
		<dd>
		<span id="RteSPSBSD1" class="sGameStatusItem large">特尾大</span><span class="num" style="margin-left:-3px;" data-id="RteSPSBSD"><?=$this->getLHCRte('RteSPSBSD',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteSPSBSD" name="SPSBS" acno="特尾大" type="text"></span>
		</dd>
		<dd>
		<span id="RteSPSBSS1" class="sGameStatusItem large">特尾小</span><span class="num" style="margin-left:-3px;" data-id="RteSPSBSS"><?=$this->getLHCRte('RteSPSBSS',$this->played)?></span>
		<span class="input" style="margin-left:-3px;"><input maxlength="5" id="RteSPSBSS" name="SPSBS" acno="特尾小" type="text"></span>
		</dd>
		</dl>
			<!--<dl>
		<dt>
		<span>号码</span><span style="width:76px;">赔率</span><span style="width:28px;">金额</span>
			</dt>
		
			</dl>-->
			<!--<dl>
		<dt>
		<span>号码</span><span style="width:76px;">赔率</span><span style="width:28px;">金额</span>
			</dt>
		
			</dl>-->
			<dl>
		<dt>
		<span>号码</span><span style="width:76px;">赔率</span><span style="width:28px;">金额</span>
			</dt>
		
			</dl>
			<dl>
		<dt>
		<span>号码</span><span style="width:76px;">赔率</span><span style="width:28px;">金额</span>
			</dt>
		
			</dl>	

    
		</div>
                 
         </div>
              </div>    </div>    </div>
            </div>
		
				<div class="addOrderBox _lhc" >
                <div class="addOrderLeft addOrderLeft625">
                                   
                   <input type="button" class="addBtn" onclick="bringRte();" value="添加投注">
                    <div class="chooseMsg">
                        <p>总金额共 <span id="sTotalCredit">0</span> 元</p>
                    </div>
                </div>
           
            </div>
            
<script>
		$("dd span").click(function(){
			var that = $(this);
			var parent = that.parent();
			if(!that.is(".input") &&　!that.is(".num")){
				if(that.is(".active")){
					 that.removeClass("active").css("background-color","#fff !important");
					 that.get(0).style.cssText='background-color:#fff !important;color:#ca1a1a !important';
					 parent.find('input[type="text"]').val("");
				}else{
					 that.addClass("active");
					 that.get(0).style.cssText='background-color:#ec2829 !important;color:white !important';
					 parent.find('input[type="text"]').val(1);
				}
			}
			parent.find("input").trigger("change");
		});
		$("dd input[type='text']").click(function(e){
			e.stopPropagation();
		})
		$("dd input[type='text']").blur(function(){
			clearCheck($(this));
		})
		 function clearCheck(that){
    	var val = that.val();
    	var lis = that.parents("dd");
    	 if(isNaN(val) && typeof val != 'number' ){
    	 	 that.val("");
    	 };
    	 if(that.val() <= 0){
    	 		that.val("");
    	 };
    	 if(that.val() == ''){
    	 	lis.find("span").eq(0).removeClass("active");
    	 	lis.find("span").eq(0).get(0).style.cssText='background-color:#fff !important;color:#ca1a1a !important';
    	 }else{
    	 	  if(!lis.find("span").eq(0).is(".active")){
    	 	  	 lis.find("span").eq(0).addClass("active");
    	 	  	 lis.find("span").eq(0).get(0).style.cssText='background-color:#ec2829 !important;color:white !important';
    	 	  }
    	 }
    }
	
</script>