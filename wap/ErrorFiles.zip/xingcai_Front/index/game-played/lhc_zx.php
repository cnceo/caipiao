<input type="hidden" name="playedGroup" value="<?=$this->groupId?>" />
<input type="hidden" name="playedId" value="<?=$this->played?>" />
<input type="hidden" name="type" value="<?=$this->type?>" />
<style type="text/css">
	.lotteryView_sxtw .sxtwBox dl dd.active{
		background-color: #F13131;
		border-color: #F13031;
	}
	.lotteryView_sxtw .sxtwBox dl dd.active span{
		color: #fff;
	}
</style>
<div class="dGameStatus hklhc lotteryView_sxtw" action="tzlhcSelect" length="1">
                <div class="Contentbox" id="Contentbox_0">
        <div class="sxtwBox" >
		<dl>
			<dt>
		<span>生肖</span><span style="margin-left:50px;">号码</span><span style="margin-left:111px;">赔率</span><span>金额</span>
			</dt>
		<dd>
		<span class="sGameStatusItem">鼠</span><span style="margin-left: 30px;" class="blue">10</span><span class="green">22</span><span class="green">34</span><span class="red">46</span><span style="margin-left:60px;" class="num" data-id="RteZXS"><?=$this->getLHCRte('RteZXS',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteZXS" name="LTTBP" acno="鼠" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">牛</span><span style="margin-left: 30px;" class="red">09</span><span class="blue">21</span><span class="green">33</span><span class="green">45</span><span style="margin-left:60px;" class="num" data-id="RteZXN"><?=$this->getLHCRte('RteZXN',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteZXN" name="LTTBP" acno="牛" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">虎</span><span style="margin-left: 30px;" class="red">08</span><span class="red">20</span><span class="blue">32</span><span class="green">44</span><span style="margin-left:60px;" class="num" data-id="RteZXH"><?=$this->getLHCRte('RteZXH',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteZXH" name="LTTBP" acno="虎" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">兔</span><span style="margin-left: 30px;" class="green">07</span><span class="red">19</span><span class="red">31</span><span class="blue">43</span><span style="margin-left:60px;" class="num" data-id="RteZXT"><?=$this->getLHCRte('RteZXT',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteZXT" name="LTTBP" acno="兔" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">龙</span><span style="margin-left: 30px;" class="green">06</span><span class="green">18</span><span class="red">30</span><span class="blue">42</span><span style="margin-left:60px;" class="num" data-id="RteZXL"><?=$this->getLHCRte('RteZXL',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteZXL" name="LTTBP" acno="龙" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">蛇</span><span style="margin-left: 30px;" class="blue">05</span><span class="green">17</span><span class="green">29</span><span class="red">41</span><span style="margin-left:60px;" class="num" data-id="RteZXShe"><?=$this->getLHCRte('RteZXShe',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteZXShe" name="LTTBP" acno="蛇" type="text"></span>
		</dd>
		</dl>
		<dl>
			<dt>
		<span>生肖</span><span style="margin-left:50px;">号码</span><span style="margin-left:111px;">赔率</span><span>金额</span>
			</dt>
		<dd>
		<span class="sGameStatusItem">马</span><span style="margin-left: 30px;" class="blue">04</span><span class="blue">16</span><span class="green">28</span><span class="green">40</span><span style="margin-left:60px;" class="num" data-id="RteZXSM"><?=$this->getLHCRte('RteZXSM',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteZXSM" name="LTTBP" acno="马" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">羊</span><span style="margin-left: 30px;" class="red">03</span><span class="blue">15</span><span class="blue">27</span><span class="green">39</span><span style="margin-left:60px;" class="num" data-id="RteZXY"><?=$this->getLHCRte('RteZXY',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteZXY" name="LTTBP" acno="羊" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">鸡</span><span style="margin-left: 30px;" class="red">01</span><span class="red">13</span><span class="blue">25</span><span class="blue">37</span><span class="green">49</span><span style="margin-left:27px;" class="num" data-id="RteZXJ"><?=$this->getLHCRte('RteZXJ',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteZXJ" name="LTTBP" acno="鸡" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">猴</span><span style="margin-left: 30px;" class="red">02</span><span class="red">14</span><span class="blue">26</span><span class="blue">38</span><span style="margin-left:60px;" class="num" data-id="RteZXSHou"><?=$this->getLHCRte('RteZXSHou',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteZXSHou" name="LTTBP" acno="猴" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">狗</span><span style="margin-left: 30px;" class="green">12</span><span class="red">24</span><span class="red">36</span><span class="blue">48</span><span style="margin-left:60px;" class="num" data-id="RteZXG"><?=$this->getLHCRte('RteZXG',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteZXG" name="LTTBP" acno="狗" type="text"></span>
		</dd>
		<dd>
		<span class="sGameStatusItem">猪</span><span style="margin-left: 30px;" class="blue">11</span><span class="green">23</span><span class="red">35</span><span class="red">47</span><span style="margin-left:60px;" class="num" data-id="RteZXZ"><?=$this->getLHCRte('RteZXZ',$this->played)?></span>
		<span class="input"><input maxlength="5" id="RteZXZ" name="LTTBP" acno="猪" type="text"></span>
		</dd>
		</dl>
	   
			  </div>  
			  </div>
            </div>
		
				<div class="addOrderBox _lhc" >
                <div class="addOrderLeft addOrderLeftsxtw">
                                   
                   <input type="button" class="addBtn" onclick="bringRte();" value="添加投注">
                    <div class="chooseMsg">
                        <p>总金额共 <span id="sTotalCredit">0</span> 元</p>
                    </div>
                </div>
           
            </div>
            
<script>
	$(".Contentbox dd").click(function(){
		var that= $(this);
		if(that.is('.active')){
			that.removeClass("active");
			that.find('input[type="text"]').val("");
		}else{
			that.addClass("active");
			that.find('input[type="text"]').val(1);
		}
		that.find("input").trigger("change");
	})
	$("dd input[type='text']").click(function(e){
		e.stopPropagation();
	})
	$("dd input[type='text']").blur(function(){
			clearCheck($(this));
		})
		 function clearCheck(that){
    	var val = that.val();
    	var lis = that.parents("dd");
    	 if(isNaN(val) && typeof val != 'number' ){
    	 	 that.val("");
    	 };
    	 if(that.val() <= 0){
    	 		that.val("");
    	 };
    	 if(that.val() == ''){
    	 	lis.removeClass("active"); 
    	 }else{   
    	 	lis.addClass("active");
    	 }
    }
</script>